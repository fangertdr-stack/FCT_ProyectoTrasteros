<?php
// api/usuarios.php
header("Access-Control-Allow-Origin: http://localhost:4200");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}
header("Content-Type: application/json");
require_once "../config.php";

try {
    // Consulta de usuarios
    if($_SERVER['REQUEST_METHOD']==='GET'){
        $stmt = $pdo->query("SELECT id_usuario, nombre, email, dni, rol,  direccion, telefono FROM usuario LIMIT 10");
        $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode($usuarios);

    }
    elseif($_SERVER['REQUEST_METHOD']==='POST'){

    $data = json_decode(file_get_contents('php://input'), true);

    if(!isset($data['id_usuario'], $data['fecha_inicio'], $data['fecha_fin'])){
        http_response_code(400);
        echo json_encode(["error"=>"Faltan datos"]);
        exit;
    }

    // Buscar un trastero libre
    $stmt = $pdo->query("SELECT * FROM trasteros WHERE estado='libre' LIMIT 1");
    $trastero = $stmt->fetch(PDO::FETCH_ASSOC);

    if(!$trastero){
        http_response_code(400);
        echo json_encode(["error"=>"No hay trasteros disponibles"]);
        exit;
    }

    // Generar código de acceso aleatorio
    $codigo = rand(100000,999999);

    // Insertar alquiler
    $stmt = $pdo->prepare("
        INSERT INTO alquileres (id_usuario, id_trastero, fecha_inicio, fecha_fin,estado, codigo_acceso)
        VALUES (:id_usuario, :id_trastero, :fecha_inicio, :fecha_fin, :estado, :codigo)
    ");
    $stmt->execute([
        ':id_usuario' => $data['id_usuario'],
        ':id_trastero' => $trastero['id_trastero'],
        ':fecha_inicio' => $data['fecha_inicio'],
        ':fecha_fin' => $data['fecha_fin'],
        ':estado' => 'pagado',
        ':codigo' => $codigo
    ]);

    // Marcar trastero como ocupado
    $stmt = $pdo->prepare("UPDATE trasteros SET estado='ocupado' WHERE id_trastero=:id_trastero");
    $stmt->execute([':id_trastero' => $trastero['id_trastero']]);

    echo json_encode(["success"=>true, "codigo"=>$codigo]);

}
    elseif($_SERVER['REQUEST_METHOD']==='PUT'){
        $data = json_decode(file_get_contents('php://input'), true);

        if (!isset($data['id_usuario'])) {
            http_response_code(400);
            echo json_encode(["error" => "Falta id_usuario"]);
            exit;
        }

        $stmt = $pdo->prepare("UPDATE usuario SET nombre = :nombre, email = :email, dni = :dni, rol = :rol, direccion = :direccion, telefono = :telefono WHERE id_usuario = :id_usuario");
        $stmt->execute([
            ':nombre' => $data['nombre'] ?? null,
            ':email' => $data['email'] ?? null,
            ':dni' => $data['dni'] ?? null,
            ':rol' => $data['rol'] ?? null,
            ':direccion' => $data['direccion'] ?? null,
            ':telefono' => $data['telefono'] ?? null,
            ':id_usuario' => $data['id_usuario']
        ]);

        echo json_encode(["success" => true]);
    }
    elseif($_SERVER['REQUEST_METHOD'] === 'DELETE') {

    if (!isset($_GET['id_usuario'])) {
        http_response_code(400);
        echo json_encode(["error" => "Falta id_usuario"]);
        exit;
    }

    $id_usuario = $_GET['id_usuario'];

    //  comprobar si tiene alquiler activo
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total 
        FROM alquileres 
        WHERE id_usuario = :id_usuario 
        AND estado = 'pagado'
    ");
    $stmt->execute([':id_usuario' => $id_usuario]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result['total'] > 0) {
        //  usuario con alquiler activo
        http_response_code(409); // 🔥 CLAVE
        echo json_encode([
            "error" => "El usuario tiene un alquiler activo"
        ]);
        exit;
    }

    //   si no tiene alquiler lo borrar
    $stmt = $pdo->prepare("DELETE FROM usuario WHERE id_usuario = :id_usuario");
    $stmt->execute([':id_usuario' => $id_usuario]);

    if ($stmt->rowCount() > 0) {
        echo json_encode(["success" => true]);
    } else {
        http_response_code(404);
        echo json_encode([
            "error" => "Usuario no encontrado"
        ]);
    }
}
    

} catch (PDOException $e) {
    
    echo json_encode(["error" => $e->getMessage()]);
}
?>
