<?php

require_once __DIR__ . '/../jwt/JWT.php';

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

class Auth {

    // VARIABLES DE LOGIN 
    private $conexion;
    public $status;
    public $message;
    public $data;

    // AUTH / JWT 
    public bool $token_valido = false;
    public bool $is_admin = false;
    public ?array $payload = null;

    // MISMA SECRET que usas al generar el token
    private string $jwt_secret = "g2R9pL6xQ1zV8nA3mK7tY5cE0wS4uI9oH6jD3bN8rP1xZ7q";

    public function __construct() {
        // Al crear la instancia, intentamos validar el token
        $token = $this->extractToken();
        if ($token) {
            try {
                $decoded = JWT::decode($token, new Key($this->jwt_secret, 'HS256'));
                $this->payload = (array)$decoded;
                $this->token_valido = true;

                $this->isAdmin(); // Marcar admin si aplica
            } catch (\Exception $e) {
                $this->token_valido = false;
                $this->payload = null;
            }
        }
    }

    // LOGIN
    public function doLogin($email, $password, $api_utils) {

        $this->conexion = new PDO(
            "mysql:host=localhost;dbname=dev2datarush;charset=utf8",
            "dev2_datarush",
            "nq73bh4mMmA43LTM",
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );

        $stmt = $this->conexion->prepare("SELECT * FROM usuario WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            $this->status = false;
            $this->message = "Usuario no encontrado";
            return;
        }

        if (!password_verify($password, $user['password'])) {
            $this->status = false;
            $this->message = "Contraseña incorrecta";
            return;
        }

        $token = $api_utils->generarJWT([
            "id_usuario" => $user["id_usuario"],
            "email"      => $user["email"],
            "rol"        => $user["rol"]
        ]);

        $this->status = true;
        $this->message = "Login correcto";
        $this->data = [
            "token"          => $token,
            "usuario"        => $user["email"],
            "nombre_publico" => $user["nombre"] ?? null,
            "rol"            => $user["rol"]
        ];
    }

    // Jwt 
    private function getBearerToken(): ?string {
        
        // Desde Authorization
        $headers = getallheaders();
        if (isset($headers['Authorization'])) return $headers['Authorization'];

        // Desde HTTP_AUTHORIZATION
        if (isset($_SERVER['HTTP_AUTHORIZATION'])) return $_SERVER['HTTP_AUTHORIZATION'];

        // Desde REDIRECT_HTTP_AUTHORIZATION
        if (isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) return $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];

        return null;
    }

    private function extractToken(): ?string {
        $authHeader = $this->getBearerToken();
        if (!$authHeader) return null;

        if (preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
            return $matches[1];
        }

        return null;
    }

    // Roles
    private function isAdmin(): void {
        $rol = $this->payload['rol'] ?? 0;
        $this->is_admin = ((int)$rol === 1);
    }
}
?>