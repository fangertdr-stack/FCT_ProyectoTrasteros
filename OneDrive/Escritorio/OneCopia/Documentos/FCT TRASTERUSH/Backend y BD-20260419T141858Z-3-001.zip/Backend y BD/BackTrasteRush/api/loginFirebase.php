<?php
header("Content-Type: application/json");
require_once "../config.php";

// Log Firebase 
try {
    $stmt = $pdo->query("SELECT id_usuario, nombre, email FROM usuarios LIMIT 10");
    $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($usuarios);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>