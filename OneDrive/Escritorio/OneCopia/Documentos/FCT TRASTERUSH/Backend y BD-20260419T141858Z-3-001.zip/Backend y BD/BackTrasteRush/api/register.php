<?php
header("Access-Control-Allow-Origin: http://localhost:4200");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(["ok" => true]);
    exit();
}

try {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!$data || !isset($data['nombre'], $data['email'], $data['password'])) {
        http_response_code(400);
        echo json_encode([
            "ok" => false,
            "message" => "Faltan datos obligatorios",
            "data" => null
        ]);
        exit();
    }

    $nombre    = trim($data['nombre']);
    $email     = trim($data['email']);
    $password  = trim($data['password']);
    $dni       = $data['dni'] ?? null;
    $telefono  = $data['telefono'] ?? null;
    $direccion = $data['direccion'] ?? null;
    $rol       = 0;

    // Conexión ÚNICA
    $pdo = new PDO(
        "mysql:host=localhost;dbname=dev2datarush;charset=utf8",
        "dev2_datarush",
        "nq73bh4mMmA43LTM"
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verificar si existe email
    $stmt = $pdo->prepare("SELECT id_usuario FROM usuario WHERE email = ?");
    $stmt->execute([$email]);
    
    if ($stmt->fetch()) {
        http_response_code(409);
        echo json_encode([
            "ok" => false,
            "message" => "El usuario ya existe",
            "data" => null
        ]);
        exit();
    }

    // INSERT usuario
    $stmt = $pdo->prepare("
        INSERT INTO usuario
        (nombre, dni, telefono, direccion, email, password, rol)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->execute([
        $nombre,
        $dni,
        $telefono,
        $direccion,
        $email,
        password_hash($password, PASSWORD_BCRYPT),
        $rol
    ]);

    http_response_code(200);
    echo json_encode([
        "ok" => true,
        "message" => "Usuario creado correctamente",
        "data" => [
            "email" => $email,
            "nombre" => $nombre,
            "rol" => $rol
        ]
    ]);
    exit();

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        "ok" => false,
        "message" => "Error: " . $e->getMessage(),
        "data" => null
    ]);
    exit();
}
?>