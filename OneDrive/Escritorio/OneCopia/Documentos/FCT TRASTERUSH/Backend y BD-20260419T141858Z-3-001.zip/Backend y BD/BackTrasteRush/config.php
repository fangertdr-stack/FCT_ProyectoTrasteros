<?php
// config.php
$host = "localhost";
$db   = "dev2datarush";      
$user = "dev2_datarush";         // Usuario MariaDB
$pass = "nq73bh4mMmA43LTM";     // Contraseña

// Conexión usando PDO (recomendado)
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}

class Conexion {

    const DB_HOST = 'localhost';
    const DB_NAME = 'dev2datarush';
    const DB_USER = 'dev2.datarush';
    const DB_PASS = 'nq73bh4mMmA43LTM';
    const DB_PORT = '3306';

    const URL = '';
    const APP_NAME = '';
    public $conexion;
    public $id_privilegio;
    public $id_usuario;

    function __construct() {
        $this->conectar();
        $this->setVariablesSession();
    }

    private function conectar() {
        try {
            $this->conexion = new PDO (
                "mysql:host=".self::DB_HOST.";port=".self::DB_PORT.";dbname=".self::DB_NAME.";charset=utf8",
                 self::DB_USER, self::DB_PASS
            );
            $this->conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Error de conexión: " . $e->getMessage());
        }
    }

    private function setVariablesSession (){
       if (isset($_SESSION['id_usuario']))
          { $this->id_usuario = $_SESSION['id_usuario']; }  

       if (isset($_SESSION['id_privilegio'])) {
           $this->id_privilegio = $_SESSION['id_privilegio'];
       } 
   }

   public function closeConnection() {
        $this->conexion = NULL;
    }

    public function trimIfString($value) {
        return is_string($value) ? trim($value) : $value;
    }

}

class Authorization extends Conexion {

     // Variables para la autorización
    public $id_usuario = NULL;
    public $token_valido = false;
    public $token = NULL;
    public $token_encrypt;
    public $is_admin;
    public $have_permision = false;
    private $id_rol = null;

    public $permises = null;

    function __construct (){
        parent::__construct();
   }

   private function getAuthorizationHeader(){

    $headers = null;
        if (isset($_SERVER['Authorization'])) {
            $headers = trim($_SERVER["Authorization"]);
        }
        else if (isset($_SERVER['HTTP_AUTHORIZATION'])) { //Nginx or fast CGI
            $headers = trim($_SERVER["HTTP_AUTHORIZATION"]);
        } elseif (function_exists('apache_request_headers')) {
            $requestHeaders = apache_request_headers();
            $requestHeaders = array_combine(array_map('ucwords', array_keys($requestHeaders)), array_values($requestHeaders));
            if (isset($requestHeaders['Authorization'])) {
                $headers = trim($requestHeaders['Authorization']);
            }
        }
        return $headers;
    }

    // Obtener el token del header Authorization
    private function getBearerToken() {
        $headers = $this->getAuthorizationHeader();
        if (!empty($headers)) {
            if (preg_match('/Bearer\s(\S+)/', $headers, $matches)) {
                $this->token = $matches[1];
            }
        }
    }

    // Comprobar si el token es valido
    public function comprobarToken() {

        $this->getBearerToken();

        $stmt = $this->conexion->prepare("SELECT * FROM usuario WHERE token_sesion = :token_sesion");
        $stmt->bindParam(":token_sesion", $this->token);
        $stmt->execute();
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($resultado) {
            $this->id_usuario = $resultado["id_usuario"];
            $this->token_valido = true;
        }
    }

    // Comprobar si el usuario es admin
    public function isAdmin(){
       $this->getIdRol();
        
        if($this->id_rol == '1'){
            $this->is_admin = true;
        } else{
            $this->is_admin = false;
        }
    }

   private function getIdRol() {
        $sql = $this->conexion->prepare("SELECT rol FROM usuario WHERE token_sesion = :token");
        $sql->bindParam(":token", $this->token);
        $sql->execute();
        $this->rol = $sql->fetch(PDO::FETCH_ASSOC)["rol"];
    }
    
}

?>