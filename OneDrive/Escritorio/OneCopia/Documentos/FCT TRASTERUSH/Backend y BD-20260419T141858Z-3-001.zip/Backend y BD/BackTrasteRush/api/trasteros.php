<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

require_once __DIR__ . "/../config.php";
global $pdo;

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

try {

    // OBTENER TRASTEROS
    if($_SERVER['REQUEST_METHOD']==='GET'){

        //  Libera trasteros vencidos
        $stmt = $pdo->prepare("
            UPDATE trasteros t
            INNER JOIN alquileres a ON t.id_trastero = a.id_trastero
            SET t.estado='libre', a.estado='finalizado'
            WHERE a.fecha_fin < CURDATE() AND t.estado='ocupado'
        ");
        $stmt->execute();

        // Trae todos los trasteros con info de alquiler vigente
        $stmt = $pdo->query("
       SELECT 
    t.id_trastero,
    t.estado,
    a.id_usuario,
    u.nombre AS usuario,
    t.tamanio,           
    t.precio,
    t.codigo ,
    a.fecha_inicio,
    a.fecha_fin,
    a.importe_total
FROM trasteros t
LEFT JOIN alquileres a
    ON a.id_trastero = t.id_trastero
    AND a.estado = 'pagado'
    AND a.fecha_fin = (
        SELECT MAX(a2.fecha_fin)
        FROM alquileres a2
        WHERE a2.id_trastero = t.id_trastero
          AND a2.estado = 'pagado'
    )
LEFT JOIN usuario u
    ON u.id_usuario = a.id_usuario
ORDER BY t.id_trastero;
        ");

        $trasteros = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode($trasteros);
    }




// CREAR O ACTUALIZAR TRASTERO (POST)
elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $data = json_decode(file_get_contents("php://input"), true);

$id_trastero = $data['id_trastero'] ?? null;
$estado = $data['estado'] ?? null;

if (!$id_trastero || !$estado) {
    http_response_code(400);
    echo json_encode(["error" => "Faltan datos obligatorios"]);
    exit;
}

try {
    // Traer el trastero
    $stmt = $pdo->prepare("SELECT estado FROM trasteros WHERE id_trastero = :id_trastero");
    $stmt->execute([':id_trastero' => $id_trastero]);
    $trastero = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$trastero) {
        http_response_code(404);
        echo json_encode(["error" => "Trastero no encontrado"]);
        exit;
    }

    // Solo mantenimiento: cambiar estado
    if ($estado === 'mantenimiento') {
        $stmt = $pdo->prepare("UPDATE trasteros SET estado = 'mantenimiento' WHERE id_trastero = :id_trastero");
        $stmt->execute([':id_trastero' => $id_trastero]);

        echo json_encode(["success" => true, "mensaje" => "Trastero en mantenimiento"]);
        exit;
    }

    // Solo libre: cambiar estado y eliminar alquiler vigente
    if ($estado === 'libre') {
        $stmt = $pdo->prepare("UPDATE trasteros SET estado = 'libre', codigo = NULL WHERE id_trastero = :id_trastero");
        $stmt->execute([':id_trastero' => $id_trastero]);

        $stmt = $pdo->prepare("DELETE FROM alquileres WHERE id_trastero = :id_trastero AND estado='pagado'");
        $stmt->execute([':id_trastero' => $id_trastero]);

        echo json_encode(["success" => true, "mensaje" => "Trastero liberado"]);
        exit;
    }

    // Ocupado: requiere usuario y fechas
    if ($estado === 'ocupado') {
        if (!isset($data['id_usuario'], $data['fecha_inicio'], $data['fecha_fin'], $data['precio_mensual_aplicado'])) {
            http_response_code(400);
            echo json_encode(["error" => "Faltan datos obligatorios para ocupar"]);
            exit;
        }

        $codigo = random_int(100000, 999999);

        $stmt = $pdo->prepare("
            INSERT INTO alquileres
            (id_usuario, id_trastero, fecha_inicio, fecha_fin, estado, precio_mensual_aplicado, importe_total, codigo_acceso)
            VALUES (:id_usuario, :id_trastero, :fecha_inicio, :fecha_fin, 'pagado', :precio, 0, :codigo)
        ");
        $stmt->execute([
            ':id_usuario' => $data['id_usuario'],
            ':id_trastero' => $id_trastero,
            ':fecha_inicio' => $data['fecha_inicio'],
            ':fecha_fin' => $data['fecha_fin'],
            ':precio' => $data['precio_mensual_aplicado'],
            ':codigo' => $codigo
        ]);

        $stmt = $pdo->prepare("UPDATE trasteros SET estado = 'ocupado', codigo = :codigo WHERE id_trastero = :id_trastero");
        $stmt->execute([
            ':codigo' => $codigo,
            ':id_trastero' => $id_trastero
        ]);

        echo json_encode(["success" => true, "codigo" => $codigo, "id_trastero" => $id_trastero]);
        exit;
    }

    http_response_code(400);
    echo json_encode(["error" => "Estado inválido"]);

} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(["error" => "Error en la base de datos", "mensaje" => $e->getMessage()]);
}
}
    // LIBERAR TRASTERO
elseif($_SERVER['REQUEST_METHOD']==='DELETE'){

    $data = json_decode(file_get_contents("php://input"), true);

    if(!isset($data['id_trastero'])){
        http_response_code(400);
        echo json_encode(["error"=>"Falta id_trastero"]);
        exit;
    }

    // 1. Liberar trastero
    $stmt = $pdo->prepare("
        UPDATE trasteros
        SET estado='libre', codigo = NULL
        WHERE id_trastero=:id_trastero
    ");

    $stmt->execute([
        ':id_trastero'=>$data['id_trastero']
    ]);

    // 2. Finalizar alquiler (SIN tocar id_usuario)
    $stmt = $pdo->prepare("
        DELETE FROM alquileres
        WHERE id_trastero=:id_trastero
        AND estado='pagado'
    ");

    $stmt->execute([
        ':id_trastero'=>$data['id_trastero']
    ]);

    echo json_encode(["success"=>true]);
}

} catch(PDOException $e){
    http_response_code(500);
    echo json_encode(["error"=>$e->getMessage()]);
}