<?php

require_once __DIR__ . '/../jwt/JWT.php';
require_once __DIR__ . '/text.php';

use Firebase\JWT\JWT;

class ApiUtils {
    const GET               = "GET";
    const POST              = "POST";
    const DELETE            = "DELETE";
    const PUT               = "PUT";
    const ALL_HEADERS       = "ALL_HEADERS";
    // const NO_TOKEN_MESSAGE  = "El token no es válido";
    public $response;

    private string $jwt_secret = "CAMBIA_ESTA_CLAVE_SUPER_SECRETA";
    private string $jwt_issuer = "trasteros-api";
    private int $jwt_ttl = 86400; // 24h

    public function setHeaders($method) {

        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Credentials: true");
        header("Access-Control-Max-Age: 1000");
        header("Access-Control-Allow-Headers: X-Requested-With, Content-Type, Origin, Cache-Control, Pragma, Authorization, Accept, Accept-Encoding");
                
        if ($method === self::ALL_HEADERS) {
            header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
        } else {
            header("Access-Control-Allow-Methods: ".$method.", OPTIONS");
        }
        header('Content-type:application/json;charset=utf-8');

    }

    public function displayErrors() {
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);
    }

    public function response($status, $message, $data, $permises = null) {
        $this->response = [
            "ok" => $status,
            "message" => $message,
            "data" => $data,
            "permises" => $permises
        ];
    }

    // GENERAR JWT
    public function generarJWT(array $payload): string {
    $secret = "g2R9pL6xQ1zV8nA3mK7tY5cE0wS4uI9oH6jD3bN8rP1xZ7q";
    $now = time();

    $tokenPayload = array_merge($payload, [
        "iat" => $now,
        "exp" => $now + 86400
    ]);

    return JWT::encode($tokenPayload, $secret, 'HS256');
}
     // VALIDAR JWT (por si luego quieres proteger endpoints)
    public function validarJWT(string $token): array {
        $decoded = JWT::decode($token, new Key($this->jwt_secret, 'HS256'));
        return (array) $decoded;
    }

    // Extrae "Bearer xxxx" del header Authorization
    public function getBearerToken(): ?string {
        $headers = function_exists('getallheaders') ? getallheaders() : [];

        $auth = $headers['Authorization'] ?? $headers['authorization'] ?? null;
        if (!$auth) return null;

        if (preg_match('/Bearer\s(\S+)/', $auth, $matches)) {
            return $matches[1];
        }
        return null;
    }

}

?>