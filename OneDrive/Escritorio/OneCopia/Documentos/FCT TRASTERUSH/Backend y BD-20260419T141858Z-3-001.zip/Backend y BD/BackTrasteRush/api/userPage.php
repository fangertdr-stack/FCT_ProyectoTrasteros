<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

require_once __DIR__ . "/../config.php";
global $pdo;

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

try {

    if ($_SERVER['REQUEST_METHOD'] === 'GET') {

        if (!isset($_GET['id_usuario'])) {
            http_response_code(400);
            echo json_encode(["error" => "Falta id_usuario"]);
            exit;
        }

        $id_usuario = $_GET['id_usuario'];

        $stmt = $pdo->prepare("
            SELECT 
                t.id_trastero,
                t.codigo,
                t.tamanio,
                t.precio,
                a.fecha_inicio AS fechaInicio,
                a.fecha_fin,
                a.estado
            FROM alquileres a
            INNER JOIN trasteros t 
                ON t.id_trastero = a.id_trastero
            WHERE a.id_usuario = :id_usuario
        ");

        $stmt->execute([
            ':id_usuario' => $id_usuario
        ]);

        $trasteros = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode($trasteros);
    }

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        "error" => "Error en la base de datos",
        "mensaje" => $e->getMessage()
    ]);
}