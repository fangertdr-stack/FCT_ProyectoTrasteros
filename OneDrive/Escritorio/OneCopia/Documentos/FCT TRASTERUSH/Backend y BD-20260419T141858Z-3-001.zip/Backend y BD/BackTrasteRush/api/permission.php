<?php

header("Access-Control-Allow-Origin: http://localhost:4200");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/api_utils.php';
require_once __DIR__ . '/auth.php';

$api_utils = new ApiUtils();
$api_utils->displayErrors();

$auth = new Auth();
$auth->comprobarToken();

// Si el token no es válido, salir
if (!$auth->token_valido) {
    http_response_code(401);
    $api_utils->response(false, "Token inválido", null, null);
    echo json_encode($api_utils->response);
    exit;
}

// Comprobamos si es admin
$auth->isAdmin();

// Devolver respuesta con is_admin y info util
$api_utils->response(true, null, [
    'is_admin' => (bool)$auth->is_admin,
    'rol'      => $auth->payload['rol'] ?? 0,
    'usuario'  => $auth->payload['email'] ?? null
], null);

echo json_encode($api_utils->response, JSON_PRETTY_PRINT);

?>