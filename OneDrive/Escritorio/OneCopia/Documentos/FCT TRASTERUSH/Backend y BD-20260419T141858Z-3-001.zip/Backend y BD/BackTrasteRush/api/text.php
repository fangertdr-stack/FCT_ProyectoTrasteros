<?php

define('NO_TOKEN_MESSAGE','El token no es válido');
define('ADD_USER_OK', 'Usuario creado con éxito');
define('ADD_USER_KO', 'Ocurrió un fallo al crear el usuario');
define('ADD_USER_NOT_PERMISION', 'No dispone de los permisos necesarios para poder añadir un usuario');
define('EDIT_USER_OK','Usuario editado con éxito');
define('EDIT_USER_KO','Ocurrió un fallo al editar el usuario');
define('EDIT_USER_NOT_PERMISION','No dispone de los permisos necesarios para poder editar un usuario');
define('DELETE_USER_OK', 'Usuario eliminado con éxito');
define('DELETE_USER_KO', 'Ocurrió un fallo al eliminar el usuario');
define('DELETE_USER_NOT_PERMISION', 'No dispone de los permisos necesarios para poder eliminar un usuario');

?>