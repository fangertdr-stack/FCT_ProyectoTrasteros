<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header("Access-Control-Allow-Origin: http://localhost:4200");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once(__DIR__ . '/auth.php');
require_once(__DIR__ . '/api_utils.php');

$api_utils = new ApiUtils();

try {
    $request = json_decode(file_get_contents('php://input'), true);

    if (!$request || !isset($request['email'], $request['password'])) {
        throw new Exception("Faltan credenciales");
    }

    $email = trim($request['email']);
    $password = trim($request['password']);

    $auth = new Auth();

    $auth->doLogin($email, $password, $api_utils);

    $api_utils->response($auth->status, $auth->message, $auth->data);

} catch (Throwable $e) {
    $api_utils->response(false, "Error interno: " . $e->getMessage(), null);
}

echo json_encode($api_utils->response, JSON_PRETTY_PRINT);
?>