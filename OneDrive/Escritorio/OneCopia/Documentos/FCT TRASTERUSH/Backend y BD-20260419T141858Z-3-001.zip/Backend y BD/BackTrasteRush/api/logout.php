<?php
require_once('./api/log.php');
require_once('../api_utils.php');

header("Access-Control-Allow-Origin: http://localhost:4200");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$api_utils = new ApiUtils();
$api_utils->setHeaders($api_utils::GET);

$usuario = $_POST['user'];

$log = new Log();
$log->generateLog( 1, "logout con éxito", $usuario);

?>